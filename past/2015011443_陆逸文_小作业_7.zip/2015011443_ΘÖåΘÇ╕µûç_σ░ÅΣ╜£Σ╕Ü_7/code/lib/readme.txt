ASM_MakeShapeModel3D.m: Compute the shape model
ASM_align_data3D.m: Align the 3d data
PCA.m: PCA
Show.m: Draw and show the triangular mesh