addpath('lib');

files = dir(fullfile('LV_data', '*.txt'));
for i = 1:length(files)
    TrainingData(i).Vertices = textread(fullfile('LV_data', files(i).name));
end

[ShapeData, TrainingData] = ASM_MakeShapeModel3D(TrainingData);

get_pc = @(i) ShapeData.Evectors(:, i);
show_vec = @(v) Show(reshape(v, [86, 3]));

% visualize the meaning of the first 3 PCs
mean_vec = ShapeData.MeanVertices(:);
figure; hold on;
for i = 1:3
    
    subplot(3, 5, 5 * (i - 1) + 1);
    show_vec(mean_vec - 200 * get_pc(i));
    axis([0, 100, -250, -100, -300, -150]);
    title(sprintf('Principal Component %d (--)', i));
    
    subplot(3, 5, 5 * (i - 1) + 2);
    show_vec(mean_vec - 100 * get_pc(i));
    axis([0, 100, -250, -100, -300, -150]);
    title(sprintf('Principal Component %d (-)', i));
    
    subplot(3, 5, 5 * (i - 1) + 3);
    show_vec(mean_vec);
    axis([0, 100, -250, -100, -300, -150]);
    title('Mean Vertices');
    
    subplot(3, 5, 5 * (i - 1) + 4);
    show_vec(mean_vec + 100 * get_pc(i));
    axis([0, 100, -250, -100, -300, -150]);
    title(sprintf('Principal Component %d (+)', i));
    
    subplot(3, 5, 5 * (i - 1) + 5);
    show_vec(mean_vec + 200 * get_pc(i));
    axis([0, 100, -250, -100, -300, -150]);
    title(sprintf('Principal Component %d (++)', i));
 
end

% reconstruct the first sample
x = ShapeData.x(:, 1);
figure; hold on;
subplot(3, 4, 1);
show_vec(x);
axis([-40, 30, -40, 60, -40, 40]);
title('Original');
coef = ShapeData.Evectors' * x;
recon = zeros(258, 1);
for n_pc = 1:11
    recon = recon + coef(n_pc) * get_pc(n_pc);
    subplot(3, 4, n_pc + 1);
    show_vec(recon);
    axis([-40, 30, -40, 60, -40, 40]);
    title(sprintf('Reconstructed with %d components', n_pc));
end