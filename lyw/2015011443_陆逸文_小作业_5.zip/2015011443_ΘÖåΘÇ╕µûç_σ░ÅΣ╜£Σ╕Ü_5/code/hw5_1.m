I = imread('binzhou.bmp');
I = im2double(I);

% show original image
figure; hold on;
subplot(1, 3, 1);
imshow(I);
title('original image');

% add noise
I = add_salt_pepper(I, 0.05);
subplot(1, 3, 2);
imshow(I);
title('image with noise');

% denoise
I = median_filter(I, 3);
subplot(1, 3, 3);
imshow(I);
title('denoised image');

function I = add_salt_pepper(I, ratio)
    % Add salt-and-pepper noise to each channel of a color image.
    % Params:
    % @I: m*n*3 matrix, a color image.
    % @ratio: scalar in (0, 1], the ratio of noise.
    [m, n, k] = size(I);
    for channel = 1:k
        for i = 1:m
            for j = 1:n
                if rand < ratio
                    if rand < 0.5
                        I(i, j, channel) = 0;
                    else
                        I(i, j, channel) = 1;
                    end
                end
            end
        end
    end
end

function I1 = median_filter(I, window_size)
    % Apply median filter to each channel of a color image.
    % Params:
    % @I: m*n*3 matrix, a color image with noise.
    % @window_size: scalar, an odd integer for the window size when taking median.
    [m, n, k] = size(I);
    I1 = I;
    half_window_size = (window_size - 1) / 2;
    for channel = 1:k
        for i = 1:m
            for j = 1:n
                rangex = max(1, i - half_window_size):min(m, i + half_window_size);
                rangey = max(1, j - half_window_size):min(n, j + half_window_size);
                window = I(rangex, rangey, channel);
                I1(i, j, channel) = median(window(:));
            end
        end
    end
end