h_tol = 0.02;
I = imread('binzhou.bmp');
I = im2double(I);
[m, n, ~] = size(I);

fig = figure;
imshow(I);
title('Draw a rectangle for ROI, then double-click');

% extract HSV channels
I = rgb2hsv(I);
h = I(:, :, 1);
s = I(:, :, 2);
v = I(:, :, 3);

% get user-specified ROI
handle = imrect;
pos = wait(handle);
delete(handle);
title('');
roi_x = max(round(pos(2)), 1):min(round(pos(2)+pos(4)), m);
roi_y = max(round(pos(1)), 1):min(round(pos(1)+pos(3)), n);
roi_h = h(roi_x, roi_y);

% find the mode of H values in ROI
[N, edges] = histcounts(roi_h);
[~, argmax] = max(N);

% calculate the range of H values for segmentation
h_center = mean(edges(argmax:(argmax+1)));
h_center = max(0, min(h_center, 1));
h_min = mod(h_center - h_tol, 1);
h_max = mod(h_center + h_tol, 1);

% segmentation
if h_min < h_max
    seg_roi = h_min <= roi_h & roi_h <= h_max;
else
    seg_roi = roi_h <= h_max | h_min <= roi_h;
end
seg = false(m, n);
seg(roi_x, roi_y) = seg_roi;

% get mean S and V values of ROI
s_mean = mean(s(seg));
v_mean = mean(v(seg));

[h_val, s_val, v_val] = color_picker(h_center, s_mean, v_mean);
h_offset = h_val - h_center;
s_offset = s_val - s_mean;
v_offset = v_val - v_mean;
h(seg) = mod(h(seg) + h_offset, 1);
clip01 = @(x) min(max(x, 0), 1);
s(seg) = clip01(s(seg) + s_offset);
v(seg) = clip01(v(seg) + v_offset);


% reconstruct image
I(:, :, 1) = h;
I(:, :, 2) = s;
I(:, :, 3) = v;
I = hsv2rgb(I);
imshow(I);


function [h, s, v] = color_picker(h, s, v)
    % GUI HSV picker.
    % Params: 3 scalars in [0, 1] for the initial HSV value.
    % Returns: 3 scalars in [0, 1] for the final HSV value.
    
    f = figure('Visible', 'off', 'Position', [0, 0, 300, 200]);
    hhint = uicontrol('Style', 'text', 'String', 'Please pick a color to change the object to:',...
        'Position', [0, 170, 300, 30]);
    htext_h = uicontrol('Style', 'text', 'String', 'H', 'Position', [5, 150, 10, 20]);
    hslider_h = uicontrol('Style', 'slider', 'String', 'H', 'Position', [30, 150, 250, 20],...
        'value', h, 'Callback', @slider_callback);
    htext_s = uicontrol('Style', 'text', 'String', 'S', 'Position', [5, 130, 10, 20]);
    hslider_s = uicontrol('Style', 'slider', 'String', 'S', 'Position', [10, 130, 250, 20],...
        'value', s, 'Callback', @slider_callback);
    htext_v = uicontrol('Style', 'text', 'String', 'V', 'Position', [5, 110, 10, 20]);
    hslider_v = uicontrol('Style', 'slider', 'String', 'V', 'Position', [10, 110, 250, 20],...
        'value', v, 'Callback', @slider_callback);
    hcolor = uicontrol('Style', 'text', 'backgroundcolor', hsv2rgb([h, s, v]),...
        'Position', [0, 80, 100, 25]);
    hbutton = uicontrol('Style', 'pushbutton', 'String', 'OK', 'Position', [0, 20, 100, 25],...
        'Callback', @(~, ~) close(f));
    align([hhint, hslider_h, hslider_s, hslider_v, hcolor, hbutton], 'Center', 'Center');
    
    function slider_callback(src, ~)
        str = src.String;
        val = get(src, 'value');
        switch str
            case 'H'
                h = val;
            case 'S'
                s = val;
            case 'V'
                v = val;
        end
        hcolor.BackgroundColor = hsv2rgb([h, s, v]);
    end
    
    f.Units = 'normalized';
    hhint.Units = 'normalized';
    htext_h.Units = 'normalized';
    htext_s.Units = 'normalized';
    htext_v.Units = 'normalized';
    hslider_h.Units = 'normalized';
    hslider_s.Units = 'normalized';
    hslider_v.Units = 'normalized';
    f.Name = 'Color picker';
    movegui(f, 'center');
    f.Visible = 'on';
    
    waitfor(f);
end