function result = enhance(I)
    % Perform the enhancement procedure on fingerprint image I.
    w = 16;
    overlap = 0.4;

    I = im2double(I);
    I = normalize(I, 0.5, 1);
    [M, N] = size(I);
    [block_positions_x, block_positions_y] = get_block_positions([M, N], [w, w],...
        [overlap, overlap]);
    O = get_orientation_map(I, w, 5, block_positions_x, block_positions_y);
    mask = ~isnan(O);
    Omega = get_frequency_map(I, O, mask, w, 2 * w, 7, 7, block_positions_x, block_positions_y,...
        [0.1, 0.5]);
    result = apply_filter(I, mask, O, Omega, w, block_positions_x, block_positions_y, 4);
end