function visualize_detail_points(I, endings, bifurcations)
    imshow(I);
    hold on;
    for i = 1:length(endings)
        ending = endings{i};
        plot(ending(2), ending(1), 'ro', 'LineWidth', 1.5, 'MarkerSize', 5);
    end
    for i = 1:length(bifurcations)
        bifurcation = bifurcations{i};
        plot(bifurcation(2), bifurcation(1), 'bo', 'LineWidth', 1.5, 'MarkerSize', 5);
    end
end