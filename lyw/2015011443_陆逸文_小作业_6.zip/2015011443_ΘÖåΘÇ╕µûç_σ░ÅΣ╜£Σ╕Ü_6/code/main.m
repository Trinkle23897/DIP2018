addpath('enhancement');

data_dir = 'data';
filenames = {'100_3.bmp', '10_1.bmp', '87_6.bmp'};

for i = 1:length(filenames)

    I = imread(fullfile(data_dir, filenames{i}));
    I = enhance(I);

    % step 1-1: binarize image
    I11 = imbinarize(I);

    % step 1-2: remove artifacts
    I12 = imopen(I11, strel('square', 2));
    I12 = imclose(I12, strel('square', 2));


    % step 2-1: thinning
    I21 = bwmorph(I12, 'thin', Inf);

    % step 2-2: pruning
    I22 = prune(I21, 10);

    % step 3: detect detail points
    [endings, bifurcations] = detect_detail_points(I22);

    % step 4: verify detail points
    true_endings = verify_endings(I22, endings);

    figure;
    subplot(2, 3, 1); imshow(I11); title('Binarized input image');
    subplot(2, 3, 2); imshow(I12); title('After removing artifacts');
    subplot(2, 3, 3); imshow(I21); title('After thinning');
    subplot(2, 3, 4); imshow(I22); title('After pruning');
    subplot(2, 3, 5); visualize_detail_points(I22, endings, bifurcations);
    title('Detected detail points');
    subplot(2, 3, 6); visualize_detail_points(I22, true_endings, bifurcations);
    title('Verified detail points');
end