function true_endings = verify_endings(I, endings)
    true_endings = {};
    n_true_endings = 0;
    for k = 1:length(endings)
        ending = endings{k};
        i = ending(1);
        j = ending(2);
        if any(I(1:(i - 1), j)) && any(I((i + 1):end, j)) && any(I(i, 1:(j - 1))) &&...
                any(I(i, (j + 1):end))
            n_true_endings = n_true_endings + 1;
            true_endings{n_true_endings} = ending;
        end
    end
end