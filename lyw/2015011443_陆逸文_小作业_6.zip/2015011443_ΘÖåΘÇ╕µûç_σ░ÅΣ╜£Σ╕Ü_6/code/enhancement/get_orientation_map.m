function O = get_orientation_map(I, w, w_Phi, block_positions_x, block_positions_y)
    % Estimate the orientation map for an image.
    %
    % Algorithm taken from subsection 2.4 of Hong, Lin, Yifei Wan, and Anil Jain. "Fingerprint image
    % enhancement: Algorithm and performance evaluation." IEEE transactions on pattern analysis and
    % machine intelligence 20, no. 8 (1998): 777-789.
    %
    % Params:
    % @I: M*N matrix, input image.
    % @w: scalar, the size of each block is w*w.
    % @w_Phi: scalar, an odd integer for the smoothing filter on the vector field.
    % @block_positions_x, block_positions_y: m-D and n-D vectors respectively, the coordinates of
    %                                        TOP-LEFT corners of each block.
    % Returns: m*n matrix, the estimated orientation map, with each element in (-pi/2, pi/2).
    
    % compute gradient
    [delta_x, delta_y] = imgradientxy(I);
    
    % least square estimation
    m = length(block_positions_x);
    n = length(block_positions_y);
    V_x = zeros(m, n);
    V_y = zeros(m, n);
    for i = 1:m
        for j = 1:n
            x = block_positions_x(i);
            y = block_positions_y(j);
            range_x = x:(x + w - 1);
            range_y = y:(y + w - 1);
            block_delta_x = delta_x(range_x, range_y);
            block_delta_y = delta_y(range_x, range_y);
            V_x(i, j) = 2 * sum(sum(block_delta_x .* block_delta_y));
            V_y(i, j) = sum(sum(block_delta_x .^ 2 - block_delta_y .^ 2));
        end
    end
    
    % convert to continuous vector field and apply low-pass filter
    V_norm = sqrt(V_x .^ 2 + V_y .^ 2);
    kernel = 1 / w_Phi ^ 2 * ones(w_Phi, w_Phi);
    Phi_x = imfilter(V_x ./ V_norm, kernel, 'replicate');
    Phi_y = imfilter(V_y ./ V_norm, kernel, 'replicate');
    
    % compute orientation map
    O = -0.5 * atan2(Phi_x, Phi_y);
end