function Omega = get_frequency_map(I, O, mask, w, l, w_Omega, w_l, block_positions_x,...
    block_positions_y, frequency_range)
    % Estimate the frequency map for the foreground of an image.
    %
    % Algorithm taken from subsection 2.5 of Hong, Lin, Yifei Wan, and Anil Jain. "Fingerprint image
    % enhancement: Algorithm and performance evaluation." IEEE transactions on pattern analysis and
    % machine intelligence 20, no. 8 (1998): 777-789.
    %
    % Params:
    % @I: M*N matrix, input image.
    % @O: m*n matrix, orientation map.
    % @mask: m*n matrix, the foreground mask for the image (block-wise).
    % @w: scalar, the size of each block is w*w.
    % @l: scalar, the size of the orientation window is l*w.
    % @w_Omega: scalar, an odd integer for the range to consider when interpolating invalid
    %           frequency values.
    % @w_l: scalar, an odd integer for the smoothing filter on the frequency map.
    % @block_positions_x, block_positions_y: m-D and n-D vectors respectively, the coordinates of
    %                                        TOP-LEFT corners of each block.
    % @frequency_range: 2D vector, min and max values for valid frequency.
    % Returns: m*n matrix, the estimated frequency map, NaN for invalid values.
    [M, N] = size(I);
    [m, n] = size(O);
    Omega = NaN(m, n);
    
    % estimate frequency from x-signature
    clip = @(x, x_min, x_max) min(max(x, x_min), x_max);
    for i = 1:m
        for j = 1:n
            if mask(i, j)
                u = @(d, k) clip(round(block_positions_x(i) + (d - w/2) * cos(O(i, j)) +...
                    (k - l/2) * sin(O(i, j))), 1, M);
                v = @(d, k) clip(round(block_positions_y(j) + (d - w/2) * sin(O(i, j)) -...
                    (k - l/2) * cos(O(i, j))), 1, N);
                X = zeros(1, l);
                for k = 1:l
                    for d = 1:w
                        X(k) = X(k) + I(u(d, k), v(d, k));
                    end
                    X(k) = X(k) / w;
                    Omega(i, j) = estimate_frequency(X);
                end
            end
        end
    end
    
    % remove illegal values
    Omega(Omega < frequency_range(1) | Omega > frequency_range(2)) = NaN;
    
    % interpolation
    for i = 1:m
        for j = 1:n
            if mask(i, j) && isnan(Omega(i, j))
                Omega(i, j) = interpolate_freq(Omega, i, j, w_Omega);
            end
        end
    end
    
    % smoothing
    Omega = smooth_freq(Omega, w_l);
end

function omega = estimate_frequency(X)
    % Estimate frequency from x-signature.
    % Params:
    % @X: k-D vector, x-signature.
    % Returns: scalar, frequency at the point, NaN if invalid.
    peaks = [];
    k = length(X);
    for i = 2:(k-1)
        if X(i) > X(i - 1) && X(i) > X(i + 1)
            peaks = [peaks, i];
        end
    end
    omega = 1 / mean(diff(peaks));
end

function omega = interpolate_freq(Omega, i, j, w_Omega)
    % Calculate the interpolated value of a certain position on the frequency map.
    % Params:
    % @Omega: m*n matrix, frequency map.
    % @i, @j: scalars, the coordinate to interpolate.
    % @w_Omega: scalar, an odd integer for the window size.
    % Returns: scalar, the interpolated frequency value.
    [m, n] = size(Omega);
    inrange = @(x, x_max) 1 <= x && x <= x_max;
    sigma = (w_Omega - 1) / 2;
    get_weight = @(x, y) exp(-((x - i) ^ 2 + (y - j) ^ 2) / (2 * sigma ^ 2));
    total_freq = 0;
    total_weight = 0;
    for x = (i - sigma):(i + sigma)
        for y = (j - sigma):(j + sigma)
            if inrange(x, m) && inrange(y, n) && ~isnan(Omega(x, y))
                weight = get_weight(x, y);
                total_freq = total_freq + weight * Omega(x, y);
                total_weight = total_weight + weight;
            end
        end
    end
    omega = total_freq / total_weight;
end

function Omega_smoothed = smooth_freq(Omega, w_l)
    % Mean filtering on frequency map.
    % Params:
    % @Omega: m*n matrix, the original frequency map.
    % @w_l: scalar, an odd integer for the window size.
    % Returns: m*n matrix, the smoothed frequency map.
    [m, n] = size(Omega);
    Omega_smoothed = NaN(m, n);
    inrange = @(x, x_max) 1 <= x && x <= x_max;
    half_w = (w_l - 1) / 2;
    for i = 1:m
        for j = 1:n
            if ~isnan(Omega(i, j))
                total_freq = 0;
                total_count = 0;
                for x = (i - half_w):(i + half_w)
                    for y = (j - half_w):(j + half_w)
                        if inrange(x, m) && inrange(y, n) && ~isnan(Omega(x, y))
                            total_freq = total_freq + Omega(x, y);
                            total_count = total_count + 1;
                        end
                    end
                end
                Omega_smoothed(i, j) = total_freq / total_count;
            end
        end
    end
end