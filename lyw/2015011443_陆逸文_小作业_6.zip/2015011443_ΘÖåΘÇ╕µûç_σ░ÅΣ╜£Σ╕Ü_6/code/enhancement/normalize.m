function I0 = normalize(I, m0, var0)
    % Normalize an image to the pre-defined mean and variance.
    % Params:
    % @I: M*N matrix, input image.
    % @m0: scalar, the desired mean.
    % @var0: scalar, the desired variance.
    % Returns: M*N matrix, the image with the desired mean and variance.
    m = mean(I(:));
    stddev = std(I(:));
    I0 = m0 + sqrt(var0) / stddev * (I - m);
end