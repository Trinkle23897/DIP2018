function [x, y] = get_block_positions(image_size, block_size, overlap)
    % Get the positions of TOP-LEFT corners of blocks on the original image.
    % Params:
    % @image_size: 2D vector, size of the original image.
    % @block_size: 2D vector, size of each block.
    % @overlap: 2D vector, each element in [0, 1), the overlapping proportion between adjacent
    %           blocks along each direction.
    % Returns:
    % @x: m-D vector, the positions of m blocks along x direction.
    % @y: n-D vector, the positions of n blocks along y direction.
    get_1d = @(axis) get_positions_1d(image_size(axis), block_size(axis), overlap(axis));
    x = get_1d(1);
    y = get_1d(2);
end

function positions = get_positions_1d(image_size, block_size, overlap)
    % Get the STARTING positions of blocks on the original image along one direction.
    % Params:
    % @image_size: scalar, size of the original image along the direction.
    % @block_size: scalar, size of the block along the direction.
    % @overlap: scalar in [0, 1), the overlapping proportion between adjacent blocks along the
    %           direction.
    % Returns: vector, the positions of the blocks.
    
    % compute number of blocks
    n = round((image_size - block_size) / ((1 - overlap) * block_size)) + 1;
    % fix the first and the last; interpolate others
    positions = linspace(1, image_size - block_size + 1, n);
    % round to nearest integer
    positions = round(positions);
end