function [endings, bifurcations] = detect_detail_points(I)
    endings = {};
    bifurcations = {};
    n_endings = 0;
    n_bifurcations = 0;
    [m, n] = size(I);
    for i = 2:(m - 1)
        for j = 2:(n - 1)
            if ~I(i, j)
                continue
            end
            neighbors = [
                I(i - 1, j - 1),...
                I(i - 1, j),...
                I(i - 1, j + 1),...
                I(i, j + 1),...
                I(i + 1, j + 1),...
                I(i + 1, j),...
                I(i + 1, j - 1),...
                I(i, j - 1)
            ];
            cn = 0;
            for k = 0:7
                cn = cn + abs(neighbors(mod(k + 1, 8) + 1) - neighbors(k + 1));
            end
            cn = cn * 0.5;
            if cn == 1 && sum(neighbors) <= 2
                n_endings = n_endings + 1;
                endings(n_endings) = {[i, j]};
            elseif cn == 3
                n_bifurcations = n_bifurcations + 1;
                bifurcations(n_bifurcations) = {[i, j]};
            end
        end
    end
end