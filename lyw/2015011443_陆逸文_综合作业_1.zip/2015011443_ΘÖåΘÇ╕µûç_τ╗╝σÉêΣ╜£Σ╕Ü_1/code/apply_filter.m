function filtered = apply_filter(I, mask, O, Omega, w, block_positions_x, block_positions_y, sigma)
    % Apply Gabor filter to each block in the original image.
    % Params:
    % @I: M*N matrix, input image.
    % @mask: m*n matrix, the foreground mask.
    % @O: m*n matrix, block-wise orientation field.
    % @Omega: m*n matrix, block-wise frequency field.
    % @block_positions_x, block_positions_y: m-D and n-D vectors respectively, the coordinates of
    %                                        TOP-LEFT corners of each block.
    % @sigma: scalar, the standard deviation for the Gaussian function in the Gabor filter.
    % Returns: M*N matrix, filtered image (the overlapping areas are filled by averaging overlapping
    %          blocks).
    [M, N] = size(I);
    filtered = zeros(M, N);
    overlap_count = zeros(M, N);
    [m, n] = size(O);
    for i = 1:m
        for j = 1:n
            if mask(i, j)
                xrange = block_positions_x(i):(block_positions_x(i) + w - 1);
                yrange = block_positions_y(j):(block_positions_y(j) + w - 1);
                block = I(xrange, yrange);
                filtered(xrange, yrange) = filtered(xrange, yrange) + ...
                    filter_block(block, O(i, j), Omega(i, j));
                overlap_count(xrange, yrange) = overlap_count(xrange, yrange) + ones(w, w);
            end
        end
    end
    filtered = filtered ./ overlap_count;
end

function result = filter_block(block, ori, freq)
    % Apply Gabor filter to a single block.
    % Params:
    % @block: w*w matrix, the input image block.
    % @ori: scalar in [-pi/2, pi/2], the orientation of stripes in the block.
    % @freq: scalar, the frequency of stripes in the block.
    % Returns: the filtered image block.
    [mag, phase] = imgaborfilt(block, 1/freq, ori * 180 / pi);
    result = mag .* cos(phase);
    result = normalize(result, 0.5, 1);
end