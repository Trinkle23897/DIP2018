function visualize_mask(I, mask, w, block_positions_x, block_positions_y)
    % Plot a mask on the original image.
    % Params:
    % @I: MxN matrix, original image.
    % @mask: mxn logical matrix, mask.
    % @w: scalar, block size.
    % @block_positions_x: m-D vector, STARTING positions along x axis of blocks on the original
    % image.
    % @block_positions_y: n-D vector, STARTING positions along y axis of blocks on the original
    % image.
    imshow(I);
    hold on;
    [m, n] = size(mask);
    for i = 1:m
        for j = 1:n
            center_x = block_positions_x(i) + ceil(w/2);
            center_y = block_positions_y(j) + ceil(w/2);
            if mask(i, j)
                plot(center_y, center_x, 'rx', 'LineWidth', 2, 'MarkerSize', 10);
            else
                plot(center_y, center_x, 'bx', 'LineWidth', 2, 'MarkerSize', 10);
            end
        end
    end
end