w = 16;
overlap = 0.2;

data_dir = 'data';
filenames = {'100_3.bmp', '10_1.bmp', '87_6.bmp'};

for filename = filenames
    figure; hold on;
    I = imread(fullfile(data_dir, filename{1}));
    I = im2double(I);
    I = normalize(I, 0.5, 1);
    [M, N] = size(I);
    [block_positions_x, block_positions_y] = get_block_positions([M, N], [w, w],...
        [overlap, overlap]);
    O = get_orientation_map(I, w, 5, block_positions_x, block_positions_y);
    subplot(1, 3, 1); visualize_orientation(I, O, w, block_positions_x, block_positions_y);
    mask = ~isnan(O);
    subplot(1, 3, 2); visualize_mask(I, mask, w, block_positions_x, block_positions_y);
    Omega = get_frequency_map(I, O, mask, w, 2 * w, 7, 7, block_positions_x, block_positions_y,...
        [0.1, 0.5]);
    subplot(1, 3, 3);
    result = apply_filter(I, mask, O, Omega, w, block_positions_x, block_positions_y, 4);
    imshow(round(result));
end