function visualize_orientation(I, O, w, block_positions_x, block_positions_y)
    % Plot the orientation map on the original image.
    % Params:
    % @I: MxN matrix, original image.
    % @O: mxn matrix, orientation map.
    % @w: scalar, block size.
    % @block_positions_x: m-D vector, STARTING positions along x axis of blocks on the original
    % image.
    % @block_positions_y: n-D vector, STARTING positions along y axis of blocks on the original
    % image.
    imshow(I);
    hold on;
    [m, n] = size(O);
    for i = 1:m
        for j = 1:n
            center_x = block_positions_x(i) + ceil(w/2);
            center_y = block_positions_y(j) + ceil(w/2);
            theta = O(i, j);
            line([center_y - w/2 * sin(theta), center_y + w/2 * sin(theta)],...
                [center_x - w/2 * cos(theta), center_x + w/2 * cos(theta)], 'linewidth', 2);
        end
    end
end