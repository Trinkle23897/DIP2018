function I = gaussian(sz, sigma)
    % Generate a 2D Gaussian function centered at (0, 0) with equal
    % variances on x, y directions.
    % params:
    % @sz: 2D vector, size of the image.
    % @sigma: Scalar, standard deviation along each axis.
    x = (1:sz(1))' - 0.5;
    y = (1:sz(2)) - 0.5;
    I = exp(-0.5 * (x .^ 2 + y .^ 2) / sigma ^ 2);
end