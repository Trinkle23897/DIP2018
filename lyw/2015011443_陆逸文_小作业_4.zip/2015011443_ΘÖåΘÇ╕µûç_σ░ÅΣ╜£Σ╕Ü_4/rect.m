function I = rect(total_sz, alpha, rect_sz, center_pos)
    % Generate a rectangular pattern.
    % params:
    % @total_sz: 2D vector, the total size of the image.
    % @alpha: Scalar, the angle by which the rectangle is rotated.
    % @rect_sz: 2D vector, the size of the rectangle.
    % @center_pos: 2D vector, the center position of the rectangle.
    
    % the coordinates of three vertices of the rectangle w.r.t. center_pos
    % without rotation
    vertices_relative = 0.5 * ([1, -1; 1, 1; -1, 1] .* rect_sz)';
    % the rotation matrix
    R = [cos(alpha), -sin(alpha); sin(alpha), cos(alpha)];
    % actual coordinates of the three vertices
    vertices = R * vertices_relative + center_pos';
    % bounds for x*sin(alpha)-y*cos(alpha)
    bounds1 = [sin(alpha), -cos(alpha)] * vertices(:, 1:2);
    % bounds for x*cos(alpha)+y*sin(alpha)
    bounds2 = [cos(alpha), sin(alpha)] * vertices(:, 2:3);
    
    % generate the pattern
    x = (1:total_sz(1))' - 0.5;
    y = (1:total_sz(2)) - 0.5;
    inrange = @(val, bounds) min(bounds) <= val & val <= max(bounds);
    I = inrange(x .* sin(alpha) - y .* cos(alpha), bounds1) & ...
        inrange(x .* cos(alpha) + y .* sin(alpha), bounds2);
    I = double(I);
end