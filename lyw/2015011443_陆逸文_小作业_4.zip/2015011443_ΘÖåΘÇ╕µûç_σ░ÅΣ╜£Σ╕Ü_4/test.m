sz = [256, 256];
I = zeros(9, 256, 256);

I(1, :, :) = sine(sz, 0, 2*pi/128, pi/2);
I(2, :, :) = sine(sz, pi/2, 2*pi/64, 0);
I(3, :, :) = sine(sz, pi/6, 2*pi/32, pi);
I(4, :, :) = rect(sz, 0, [40, 20], [128, 128]);
I(5, :, :) = rect(sz, pi/6, [40, 20], [128, 128]);
I(6, :, :) = rect(sz, 0, [40, 20], [64, 64]);
I(7, :, :) = gaussian(sz, 10);
I(8, :, :) = gaussian(sz, 50);
I(9, :, :) = gaussian(sz, 100);

current_I = zeros(sz);
for i = 1:size(I, 1)
    current_I(:) = I(i, :, :);
    [magnitude, phase] = dft(current_I);
    if mod(i, 3) == 1
        figure; hold on;
    end
    subplot(3, 4, 4 * mod(i - 1, 3) + 1);
    imshow(current_I, [min(min(current_I)), max(max(current_I))]);
    title('Original image');
    subplot(3, 4, 4 * mod(i - 1, 3) + 2);
    imshow(magnitude, [min(min(magnitude)), max(max(magnitude))]);
    title('Magnitude');
    log_magnitude = log(magnitude);
    subplot(3, 4, 4 * mod(i - 1, 3) + 3);
    imshow(log_magnitude, [min(min(log_magnitude)), max(max(log_magnitude))]);
    title('Log Magnitude');
    subplot(3, 4, 4 * mod(i - 1, 3) + 4);
    imshow(phase, [min(min(phase)), max(max(phase))]);
    title('Phase');
    if mod(i, 3) == 0
        hold off;
    end
end