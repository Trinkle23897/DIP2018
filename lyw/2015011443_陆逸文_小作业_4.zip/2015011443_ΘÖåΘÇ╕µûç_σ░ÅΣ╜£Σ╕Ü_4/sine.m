function I = sine(sz, angle, omega, phi)
    % Generate an 2D sine wave f=sin(omega*t+phi).
    % params:
    % @sz: 2D vector, size of the image.
    % @angle: Scalar, orientation of the axis by which t is calculated;
    %   t is defined as the distance to (0, 0) along the axis;
    %   "angle" is the angle from x axis to that axis.
    % @omega: Scalar, angular frequency.
    % @phi: Scalar, initial phase.
    
    x = (1:sz(1))' - 0.5;
    y = (1:sz(2)) - 0.5;
    t = x .* cos(angle) + y .* sin(angle);
    I = sin(omega * t + phi);
end