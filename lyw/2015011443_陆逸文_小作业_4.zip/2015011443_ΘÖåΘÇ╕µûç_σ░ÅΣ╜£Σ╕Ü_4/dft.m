function [magnitude, phase] = dft(I)
    [M, N] = size(I);
    
    % place the DC component at the center
    I = I .* ((-1) .^ xor(mod((0:M-1)', 2), mod((0:N-1), 2)));
    
    % exp(-j*2*pi*ux/M)
    e1 = exp(-2i * pi / M * ((0:M-1)' .* (0:M-1)));
    % exp(-j*2*pi*vy/N)
    e2 = exp(-2i * pi / N * ((0:N-1)' .* (0:N-1)));
    F = e1 * I * e2;
    magnitude = abs(F);
    phase = angle(F);
end