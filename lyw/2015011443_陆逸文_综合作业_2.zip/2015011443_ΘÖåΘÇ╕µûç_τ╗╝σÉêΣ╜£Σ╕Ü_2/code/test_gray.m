addpath('ref_code');

f = imread(['data' filesep 'lena_gray.bmp']);
figure;
imshow(f);
title('Original image');

fprintf('Quality\tCR (w/o LPC)\tCR (LPC)\tRMSE (w/o LPC)\tRMSE (LPC)\tLength (w/o LPC)\tLength (LPC)\n');

for quality = [1, 5, 10, 20]
    c_original = im2jpeg(f, quality);
    f_original = jpeg2im(c_original);
    c_original.huffmanDict = compress_huffman_dict(c_original.huffmanDict);
    cr_original = imratio(f, c_original);
    rmse_original = CompareImages(f, f_original);
    c_lpc = im2jpeg_lpc(f, quality);
    f_lpc = jpeg2im_lpc(c_lpc);
    cr_lpc = imratio(f, c_lpc);
    rmse_lpc = CompareImages(f, f_lpc);
    fprintf('%d\t%f\t%f\t%f\t%f\t%d\t%d\n', quality, cr_original, cr_lpc, rmse_original, rmse_lpc,...
        c_original.huffmanCodeLen, c_lpc.huffmanCodeLen);
    figure; imshow(f_original); title(sprintf('Compressed w/o LPC (quality: %d)', quality));
    figure; imshow(f_lpc); title(sprintf('Compressed with LPC (quality: %d)', quality));
    imwrite(f_lpc, sprintf('lpc_%d.bmp', quality));
end