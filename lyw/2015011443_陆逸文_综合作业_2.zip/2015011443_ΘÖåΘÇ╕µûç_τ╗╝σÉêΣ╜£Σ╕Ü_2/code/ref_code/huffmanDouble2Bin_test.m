x = [1 0 0 1 0 1 0 1 1 1]
y = huffmanDouble2Bin(x)