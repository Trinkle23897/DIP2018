function dict = decompress_huffman_dict(compressed)
    % decompress_huffman_dict: convert a compressed int8 matrix the cell array format returned by
    % huffmandict.
    
    n = size(compressed, 1);
    dict = cell(n, 2);
    for i = 1:n
        dict{i, 1} = double(compressed(i, 1));
        dict{i, 2} = decompress_bytes(compressed(i, 3:end), compressed(i, 2));
    end

end


function bits = decompress_bytes(bytes, n_bits)
    % decompress_bytes: decompress an array of int8 into a double array of length n_bits
    % representing the bits.
    n_bits = double(n_bits);
    bits = zeros(1, n_bits);
    for i = 1:n_bits
        ind_byte = floor((i - 1) / 8) + 1;
        ind_in_byte = mod(i - 1, 8) + 1;
        bits(i) = bitget(bytes(ind_byte), ind_in_byte);
    end
end