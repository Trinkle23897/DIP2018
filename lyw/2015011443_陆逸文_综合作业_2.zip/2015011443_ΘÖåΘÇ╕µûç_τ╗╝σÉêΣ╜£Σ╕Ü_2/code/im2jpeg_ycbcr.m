function y = im2jpeg_ycbcr(x_rgb, quality)
% im2jpeg_rgb: Compress RGB image x using JPEG by using YCbCr color space, with lossless predictive
% coding for DC components.
% reference: DIPUM; im2jpeg by Jianjiang Feng
% Yiwen Lu
% 2017-12-06

sz = size(x_rgb);

if ~length(sz) == 3 || ~sz(3) == 3 || ~isa(x_rgb, 'uint8')
    error('The input x must be an RGB UINT8 image.');
end

if nargin < 2
    quality = 1; % default quality
end

% normalization matrix
m = [16 11 10 16 24 40 51 61 
    12 12 14 19 26 58 60 55 
    14 13 16 24 40 57 69 56 
    14 17 22 29 51 87 80 62 
    18 22 37 56 68 109 103 77 
    24 35 55 64 81 104 113 92 
    49 64 78 87 103 121 120 101 
    72 92 95 98 112 100 103 99] * quality;

% zig-zag order
order = [1 9 2 3 10 17 25 18 11 4 5 12 19 26 33 ...
        41 34 27 20 13 6 7 14 21 28 35 42 49 57 50 ...
        43 36 29 22 15 8 16 23 30 37 44 51 58 59 52 ...
        45 38 31 24 32 39 46 53 60 61 54 47 40 48 55 ...
        62 63 56 64];
    
x_ycbcr = rgb2ycbcr(x_rgb);
    
r = zeros(numel(x_rgb) / 2, 1);
count = 0;
eobs = zeros(1, 3);
xbs = zeros(1, 3);


for channel = 1:3
    
    x = x_ycbcr(:, :, channel);
    if channel > 1
        x = imresize(x, 0.5);
    end
    
    [xm1, xn1] = size(x);
    xm = ceil(xm1/8)*8;
    xn = ceil(xn1/8)*8;
    
    if (channel == 1)
        xm_y = xm;
        xn_y = xn;
        xm1_y = xm1;
        xn1_y = xn1;
    else
        xm_cbcr = xm;
        xn_cbcr = xn;
        xm1_cbcr = xm;
        xn1_cbcr = xn;
    end
    
    x = padarray(x,[xm-xm1 xn-xn1],0,'post');

    x = double(x) - 128;
    t = dctmtx(8);

    % Compute DCTs of 8x8 blocks and quantize the coefficients.
    fun_DCT = @(block_struct) t * block_struct.data * t';
    y = blockproc(x, [8 8], fun_DCT);

    fun_quantize = @(block_struct) round(block_struct.data ./ m);
    y = blockproc(y, [8 8], fun_quantize);

    y = im2col(y, [8 8], 'distinct');
    xb = size(y, 2);
    xbs(channel) = xb;

    if 0% Show DC as image
        figure(10),clf,
        imshow(imresize(reshape(y(1,:),xm/8,xn/8),8,'nearest'),[])
        title('DC');
    end

    y = y(order, :); % reorder
    

    % encode values into r

    % step 1: LPC for DC components
    block_m = xm / 8;
    block_n = xn / 8;
    dc = reshape(y(1, :), block_m, block_n);
    r(count + 1:count + block_m) = [dc(1, 1); diff(dc(:, 1))];
    count = count + block_m;
    for i = 1:block_m
        r(count + 1:count + block_n - 1) = diff(dc(i, :));
        count = count + block_n - 1;
    end

    % step 2: place AC components
    y = y(2:end, :);
    eob = max(y(:))+1;
    eobs(channel) = eob;
    for j = 1:xb
        i = find(y(:,j), 1, 'last');
        if isempty(i)
            i = 0;
        end
        p = count + 1;
        q = p + i;
        r(p:q) = [y(1:i, j); eob];
        count = count + i + 1;
    end
    
end

r((count+1):end) = [];
clear y
y.original_size_y = uint16([xm1_y xn1_y]);
y.original_size_cbcr = uint16([xm1_cbcr xn1_cbcr]);
y.size_y = uint16([xm_y xn_y]);
y.size_cbcr = uint16([xm_cbcr xn_cbcr]);
y.numblocks = uint16(xbs);
y.quality = uint16(quality*100);
y.eobs = eobs;

[symbols, prob] = prob4huffman(r);
dict = huffmandict(symbols,prob);
y.huffmanDict = compress_huffman_dict(dict);
hcode = huffmanenco(r,dict);
[y.huffmanCode,y.huffmanCodeLen] = huffmanDouble2Bin(hcode);