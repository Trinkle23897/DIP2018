addpath('ref_code');

f = imread(['data' filesep 'lena_std.tif']);
figure;
imshow(f);
title('Original image');

fprintf('Quality\tCR (RGB)\tCR (YCbCr)\tRMSE (RGB)\tRMSE (YCbCr)\tTime (RGB)\tTime (YCbCr)\n');

for quality = [1, 5, 10, 20]
    tic;
    c_rgb = im2jpeg_rgb(f, quality);
    f_rgb = jpeg2im_rgb(c_rgb);
    t_rgb = toc;
    cr_rgb = imratio(f, c_rgb);
    rmse_rgb = CompareImages(f, f_rgb);
    tic;
    c_ycbcr = im2jpeg_ycbcr(f, quality);
    f_ycbcr = jpeg2im_ycbcr(c_ycbcr);
    t_ycbcr = toc;
    cr_ycbcr = imratio(f, c_ycbcr);
    rmse_ycbcr = CompareImages(f, f_ycbcr);
    fprintf('%d\t%f\t%f\t%f\t%f\t%f\t%f\n', quality, cr_rgb, cr_ycbcr, rmse_rgb, rmse_ycbcr,...
        t_rgb, t_ycbcr);
    figure; imshow(f_rgb); title(sprintf('RGB (quality: %d)', quality));
    figure; imshow(f_ycbcr); title(sprintf('YCbCr (quality: %d)', quality));
    imwrite(f_rgb, sprintf('rgb_%d.bmp', quality));
    imwrite(f_ycbcr, sprintf('ycbcr_%d.bmp', quality));
end