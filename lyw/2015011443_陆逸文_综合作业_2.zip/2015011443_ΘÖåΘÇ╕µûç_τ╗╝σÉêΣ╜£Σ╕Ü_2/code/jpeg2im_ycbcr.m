function x = jpeg2im_ycbcr(y)
% jpeg2im_rgb: Decode an IM2JPEG_YCBCR compressed RGB image.
% reference: DIPUM; jpeg2im by Jianjiang Feng
% Yiwen Lu
% 2017-12-06

% normalization matrix
m = [16 11 10 16 24 40 51 61 
    12 12 14 19 26 58 60 55 
    14 13 16 24 40 57 69 56 
    14 17 22 29 51 87 80 62 
    18 22 37 56 68 109 103 77 
    24 35 55 64 81 104 113 92 
    49 64 78 87 103 121 120 101 
    72 92 95 98 112 100 103 99];

% zig-zag order
order = [1 9 2 3 10 17 25 18 11 4 5 12 19 26 33 ...
        41 34 27 20 13 6 7 14 21 28 35 42 49 57 50 ...
        43 36 29 22 15 8 16 23 30 37 44 51 58 59 52 ...
        45 38 31 24 32 39 46 53 60 61 54 47 40 48 55 ...
        62 63 56 64];
    
rev = order;
for count = 1:length(order)
    rev(count) = find(order == count);
end

m = double(y.quality)/100*m;
xbs = double(y.numblocks);
sz_y = double(y.size_y);
xn_y = sz_y(2);
xm_y = sz_y(1);
sz_cbcr = double(y.size_cbcr);
xn_cbcr = sz_cbcr(2);
xm_cbcr = sz_cbcr(1);
x = uint8(zeros(xm_y, xn_y, 3));

hcode = huffmanBin2Double(y.huffmanCode,y.huffmanCodeLen);
r = huffmandeco(hcode, decompress_huffman_dict(y.huffmanDict));
count = 0;

for channel = 1:3

    xb = xbs(channel);
    z = zeros(64, xb);
    if channel == 1
        xn = xn_y;
        xm = xm_y;
    else
        xn = xn_cbcr;
        xm = xm_cbcr;
    end

    % extract values from r into z

    % step 1: extract DC components
    block_m = xm / 8;
    block_n = xn / 8;
    dc = zeros(block_m, block_n);
    dc(:, 1) = cumsum(r(count + 1:count + block_m));
    count = count + block_m;
    for i = 1:block_m
        dc(i, 2:end) = dc(i, 1) + cumsum(r(count + 1:count + block_n - 1));
        count = count + block_n - 1;
    end

    z(1, :) = dc(:);

    % step 2: extract AC components
    eob = y.eobs(channel);
    for j = 1:xb
        for i = 2:64
            if r(count + 1)==eob
                count = count+1;
                break
            else
                z(i, j) = r(count + 1);
                count = count + 1;
            end
        end
    end

    z = z(rev, :);
    x_channel = col2im(z, [8 8], [xm xn], 'distinct');

    fun_denormalize = @(block_struct) round(block_struct.data .* m);
    x_channel = blockproc(x_channel, [8 8], fun_denormalize);

    t = dctmtx(8);
    fun_IDCT = @(block_struct) t' * block_struct.data * t;
    x_channel = blockproc(x_channel, [8 8], fun_IDCT);
    x_channel = uint8(x_channel+128);
    if channel == 1
        x_channel = x_channel(1:y.original_size_y(1), 1:y.original_size_y(2));
    else
        x_channel = x_channel(1:y.original_size_cbcr(1), 1:y.original_size_cbcr(2));
        x_channel = imresize(x_channel, y.original_size_y);
    end
    x(:, :, channel) = x_channel;
end

x = ycbcr2rgb(x);