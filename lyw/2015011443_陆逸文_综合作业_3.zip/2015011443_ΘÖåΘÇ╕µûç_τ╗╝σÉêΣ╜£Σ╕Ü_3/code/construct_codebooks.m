function codebooks = construct_codebooks(video, eps1)

n_frames = size(video, 1);
h = size(video, 2);
w = size(video, 3);

codebooks = CodeBook.empty(h, 0);

for i = 1:h
    for j = 1:w
        codebooks(i, j) = CodeBook();
    end
end

% construct codebook
for t = 1:n_frames
    fprintf('Updating codebooks for frame %d\n', t);
    frame = im2double(reshape(video(t, :, :, :), [h, w, 3]));
    for i = 1:h
        for j = 1:w
            RGB = reshape(frame(i, j, :), [3, 1]);
            codebook = codebooks(i, j);
            matched = false;
            for k = 1:codebook.n_words
                word = codebook.words(k);
                if word.match(RGB, eps1)
                    word.update(RGB, t);
                    matched = true;
                    break;
                end
            end
            if ~matched
                codebook.add_word(CodeWord(RGB, t));
            end
        end
    end
end

t = t + 1;

for i = 1:h
    for j = 1:w
        codebook = codebooks(i, j);
        for k = 1:codebook.n_words
            word = codebook.words(k);
            word.update_MNRL(t);
        end
    end
end