function delta = colordist(x, v)
    if ~norm(v)
        delta = norm(x);
    else
        p_sqr = (x' * v) ^ 2 / norm(v) ^ 2;
        delta = sqrt(norm(x) ^ 2 - p_sqr);
    end
end