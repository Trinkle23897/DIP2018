function centroids = get_centroid(mask)

n_frames = size(mask, 1);
h = size(mask, 2);
w = size(mask, 3);

centroids = zeros(n_frames, 2);

get_mask = @(i) reshape(mask(i, :, :), [h, w]);

for i = 1:n_frames
    stats = regionprops(get_mask(i));
    centroids(i, :) = [stats.Centroid(2), stats.Centroid(1)];
end