function mask = postprocess_mask(mask)

% close gaps
mask = imclose(mask, strel('sphere', 3));

% fill small holes
filled = imfill(mask, 'holes');
holes = filled & ~mask;
bigholes = bwareaopen(holes, 20);
smallholes = holes & ~bigholes;
mask = mask | smallholes;

% remove thin connections
mask = imopen(mask, strel('disk', 4));

% select largest connected component
cc = bwconncomp(mask);
numPixels = cellfun(@numel, cc.PixelIdxList);
[~, argmax] = max(numPixels);
for i = 1:length(numPixels)
    if i ~= argmax
        mask(cc.PixelIdxList{i}) = 0;
    end
end

% close gaps again
mask = imclose(mask, strel('sphere', 10));
