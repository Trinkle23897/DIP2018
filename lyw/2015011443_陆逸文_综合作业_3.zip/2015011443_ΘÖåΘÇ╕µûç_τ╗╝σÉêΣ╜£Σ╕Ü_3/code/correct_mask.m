function mask = correct_mask(mask)

thresh1 = 10;
thresh2 = 8;

n_frames = size(mask, 1);
h = size(mask, 2);
w = size(mask, 3);

centroids = get_centroid(mask);
centroids_kalman = kalman_filter(centroids);

abnormal = false;
for i = 2:n_frames
    if ~abnormal
        if norm(centroids(i, :) - centroids(i - 1, :)) > thresh2
            fprintf('Detected abnormal value in frame %d\n', i);
            offset = centroids_kalman(i, :) - centroids_kalman(i - 1, :);
            mask(i, :, :) = imtranslate(reshape(mask(i - 1, :, :), [h, w]), [offset(2), offset(1)]);
            abnormal = true;
        end
    else
        if norm(centroids(i, :) - centroids_kalman(i, :)) <= thresh1
            fprintf('Back to normal in frame %d\n', i);
            abnormal = false;
        else
            offset = centroids_kalman(i, :) - centroids_kalman(i - 1, :);
            mask(i, :, :) = imtranslate(reshape(mask(i - 1, :, :), [h, w]), [offset(2), offset(1)]);
        end
    end
end