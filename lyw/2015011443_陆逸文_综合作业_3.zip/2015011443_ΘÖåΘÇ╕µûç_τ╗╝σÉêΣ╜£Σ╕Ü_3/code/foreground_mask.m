function mask = foreground_mask(video, codebooks, eps2)

n_frames = size(video, 1);
h = size(video, 2);
w = size(video, 3);

mask = uint8(zeros(n_frames, h, w));
for t = 1:n_frames
    fprintf('Generating foreground mask for frame %d\n', t);
    frame = im2double(reshape(video(t, :, :, :), [h, w, 3]));
    for i = 1:h
        for j = 1:w
            RGB = reshape(frame(i, j, :), [3, 1]);
            codebook = codebooks(i, j);
            matched = false;
            for k = 1:codebook.n_words
                word = codebook.words(k);
                if word.match(RGB, eps2)
                    matched = true;
                    break;
                end
            end
            if ~matched
                mask(t, i, j) = 1;
            end
        end
    end
end