function [I_low, I_hi] = brightness_range(I_min, I_max)
    alpha = 0.5;
    beta = 1.2;
    I_low = alpha * I_max;
    I_hi = min(beta * I_max, I_min / alpha);
end