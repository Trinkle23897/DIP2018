function sigma = sigma_map(mask)

[H, W] = size(mask);

H_B = 192;  % height of horizon
max_sigma = 2;

rowsum = sum(mask, 2);
x0 = find(rowsum, 1, 'last');
col = max_sigma * [ones(H - H_B, 1); linspace(1, 0, H_B + x0 - H)'; zeros(H - x0, 1)];
bg_sigma = repmat(col, 1, W);

fg_affinity = double(mask);
aff = 0.95;
while aff > 0
    mask_dilated = imdilate(mask, strel('sphere', 1));
    edge = mask_dilated & ~mask;
    fg_affinity(edge) = aff;
    mask = mask_dilated;
    aff = aff - 0.05;
end

sigma = (1 - fg_affinity) .* bg_sigma;