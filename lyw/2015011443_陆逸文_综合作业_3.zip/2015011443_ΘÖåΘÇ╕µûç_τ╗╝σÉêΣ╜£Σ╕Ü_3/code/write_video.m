function write_video(video, file)

writer = VideoWriter(file, 'MPEG-4');
n_frames = size(video, 1);
h = size(video, 2);
w = size(video, 3);
open(writer);
for i = 1:n_frames
    if ndims(video) == 4
        frame = reshape(video(i, :, :, :), [h, w, 3]);
    else
        frame = repmat(double(reshape(video(i, :, :), [h, w])), [1, 1, 3]);
    end
    writeVideo(writer, frame);
end
close(writer);