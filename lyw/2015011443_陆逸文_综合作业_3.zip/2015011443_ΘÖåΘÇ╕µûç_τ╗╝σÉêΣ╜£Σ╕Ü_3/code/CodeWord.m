classdef CodeWord < handle
    properties
        RGB
        I_min
        I_max
        freq
        MNRL
        first_access
        last_access
    end
    
    methods
        function obj = CodeWord(RGB, t)
            if nargin > 0
                I = norm(RGB);
                obj.RGB = RGB;
                obj.I_min = I;
                obj.I_max = I;
                obj.freq = 1;
                obj.MNRL = t - 1;
                obj.first_access = t;
                obj.last_access = t;
            end
        end
        function is_matched = match(obj, RGB, max_colordist)
            I = norm(RGB);
            [I_low, I_hi] = brightness_range(obj.I_min, obj.I_max);
            is_matched = colordist(RGB, obj.RGB) <= max_colordist && I_low <= I && I <= I_hi;
        end
        function update(obj, RGB, t)
            I = norm(RGB);
            obj.RGB = (obj.freq * obj.RGB + RGB) / (obj.freq + 1);
            obj.I_min = min(I, obj.I_min);
            obj.I_max = max(I, obj.I_max);
            obj.freq = obj.freq + 1;
            obj.update_MNRL(t);
            obj.last_access = t;
        end
        function update_MNRL(obj, t)
            obj.MNRL = max(obj.MNRL, t - obj.last_access);
        end
    end
    
end
