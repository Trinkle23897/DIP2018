function [video, T] = stabilize_video(video)

roi_range = [1, 320, 60, 568];

n_frames = size(video, 1);
h = size(video, 2);
w = size(video, 3);

T = zeros(n_frames, 3, 3);

get_frame = @(i) reshape(video(i, :, :, :), [h, w, 3]);
get_roi = @(frame) frame(roi_range(1):roi_range(3), roi_range(2):roi_range(4), :);

fixed = get_roi(get_frame(1));
ref = imref2d([h, w, 3]);
for i = 2:n_frames
    fprintf('Calibrating frame %d\n', i);
    frame = get_frame(i);
    tform = imregcorr(get_roi(frame), fixed);
    T(i, :, :) = tform.T;
    video(i, :, :, :) = imwarp(frame, tform, 'OutputView', ref);
end