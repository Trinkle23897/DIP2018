classdef CodeBook < handle

    properties
        n_words = 0;
        words = CodeWord.empty;
    end
    
    methods
        function add_word(obj, word)
            obj.n_words = obj.n_words + 1;
            obj.words(obj.n_words) = word;
        end
        function remove_foreground(obj, min_freq, max_MNRL)
            selected_ind = [];
            for i = 1:obj.n_words
                if obj.words(i).freq >= min_freq || obj.words(i).MNRL <= max_MNRL
                    selected_ind = [selected_ind, i];
                end
            end
            obj.words = obj.words(selected_ind);
            obj.n_words = length(obj.words);
        end
    end
    
end

