eps1 = 0.1;
eps2 = 0.1;
max_MRNL = 60;
min_freq = 150;

video_reader = VideoReader('input_video.mp4');
h = video_reader.Height;
w = video_reader.Width;
video = uint8(zeros(1, h, w, 3));
t = 1;
while hasFrame(video_reader)
    fprintf('Reading frame %d\n', t);
    frame = readFrame(video_reader);
    video(t, :, :, :) = frame;
    t = t + 1;
end
save('video.mat', 'video');

[video_stabilized, T] = stabilize_video(video);
save('video_stabilized.mat', 'video_stabilized', 'T');
write_video(video_stabilized, 'video_stabilized');

codebooks = construct_codebooks(video, eps1);
save('codebook1.mat', 'codebooks');

disp('Removing foreground codewords');
for i = 1:h
    for j = 1:w
        codebooks(i, j).remove_foreground(min_freq, max_MRNL);
    end
end
save('codebook2.mat', 'codebooks');

mask = foreground_mask(video, codebooks, eps2);
save('mask.mat', 'mask');

n_frames = size(mask, 1);
get_mask = @(i) reshape(mask(i, :, :), [h, w]);
for i = 1:n_frames
    fprintf('Postprocessing mask %d\n', i);
    mask(i, :, :) = postprocess_mask(get_mask(i));
end
save('mask1.mat', 'mask');
write_video(mask, 'mask1');

last_frame = 465;   % no foreground object after that
mask = mask(1:last_frame, :, :);
mask = correct_mask(mask);
save('mask2.mat', 'mask');
write_video(mask, 'mask2');

sigma = zeros(last_frame, h, w);
get_mask = @(i) reshape(mask(i, :, :), [h, w]);
for i = 1:last_frame
    fprintf('Computing sigma map for frame %d\n', i);
    sigma(i, :, :) = sigma_map(get_mask(i));
end
save('sigma.mat', 'sigma');

disp('Smoothing sigma map');
window_size = 10;
window = gausswin(window_size);
window = window / sum(window);
for i = 1:h
    for j = 1:w
        seq = reshape(sigma(:, i, j), [last_frame, 1]);
        seq = [seq(1) * ones(window_size, 1); seq; seq(last_frame) * ones(window_size, 1)];
        seq = filter(window, 1, seq);
        seq = seq(window_size + 1:window_size + last_frame);
        sigma(:, i, j) = seq;
    end
end
save('sigma1.mat', 'sigma');

sigma_complete = zeros(n_frames, h, w);
sigma_complete(1:last_frame, :, :) = sigma;
sigma_complete(last_frame + 1:end, :, :) = repmat(sigma(last_frame, :, :), [n_frames - last_frame, 1, 1]);

ref = imref2d([h, w]);
get_sigma = @(i) reshape(sigma_complete(i, :, :), [h, w]);
get_T = @(i) invert(affine2d(reshape(T(i, :, :), [3, 3])));
for i = 2:n_frames
    fprintf('Performing inverse transform for frame %d\n', i);
    sigma_complete(i, :, :) = imwarp(get_sigma(i), get_T(i), 'OutputView', ref);
end
save('sigma2.mat', 'sigma_complete');

parfor i = 1:n_frames
    fprintf('Filtering frame %d\n', i);
    frame = im2double(reshape(video(i, :, :, :), [h, w, 3]));
    frame_sigma = reshape(sigma_complete(i, :, :), [h, w]);
    video(i, :, :, :) = im2uint8(gaussian_filter_rgb(frame, frame_sigma));
end
save('video_final.mat', 'video');
write_video(video, 'output');