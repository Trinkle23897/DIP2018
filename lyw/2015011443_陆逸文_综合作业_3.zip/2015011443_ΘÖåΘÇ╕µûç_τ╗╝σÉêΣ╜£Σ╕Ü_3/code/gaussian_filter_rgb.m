function filtered = gaussian_filter_rgb(rgb, sigma)
    % expected rgb to be h*w*3, sigma to be h*w
    [h, w] = size(sigma);
    pad_size = 4;
    filtered = zeros(h, w, 3);
    for channel = 1:3
        image = rgb(:, :, channel);
        padded = pad_image(image, pad_size);
        for i = 1:h
            for j = 1:w
                if sigma(i, j) > 0
                    kernel = make_kernel(sigma(i, j));
                    patch = get_patch(padded, i + pad_size, j + pad_size, size(kernel, 1));
                    filtered(i, j, channel) = sum(sum(kernel .* patch));
                else
                    filtered(i, j, channel) = rgb(i, j, channel);
                end
            end
        end
    end
end

function kernel = make_kernel(sigma)
    half_sz = round(2 * sigma);
    kernel = fspecial('gaussian', 2 * half_sz + 1, sigma);
end

function I_padded = pad_image(I, pad_size)
    m = size(I, 1);
    n = size(I, 2);
    pad_topleft = I(1, 1) * ones(pad_size, pad_size);
    pad_top = repmat(I(1, :), pad_size, 1);
    pad_topright = I(1, n) * ones(pad_size, pad_size);
    pad_left = repmat(I(:, 1), 1, pad_size);
    pad_right = repmat(I(:, n), 1, pad_size);
    pad_bottomleft = I(m, 1) * ones(pad_size, pad_size);
    pad_bottom = repmat(I(m, :), pad_size, 1);
    pad_bottomright = I(m, n) * ones(pad_size, pad_size);
    I_padded = [
            pad_topleft,    pad_top,    pad_topright;
            pad_left,       I,          pad_right;
            pad_bottomleft, pad_bottom, pad_bottomright
        ];
end

function patch = get_patch(img, x, y, sz)
    half_sz = (sz - 1) / 2;
    x_range = x - half_sz : x + half_sz;
    y_range = y - half_sz : y + half_sz;
    patch = img(x_range, y_range);
end