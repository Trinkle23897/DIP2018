function AddNoiseBatch(path)
    % Read all .jpg files under the given path, resize, add noise, and save
    % to .bmp files.
    listing = dir(fullfile(path, '*.jpg'));
    filenames = {listing(~[listing.isdir]).name};
    for filename_cell = filenames
        % 1. read image
        filename = filename_cell{1};
        filepath = fullfile(path, filename);
        [~, basename] = fileparts(filepath);
        try
            l1 = imread(filepath);
        catch
            fprintf('Unable to open image: %s\n', filepath);
            continue;
        end
        
        % 2. convert RGB to grayscale if necessary
        if size(l1, 3) == 3
            % the image is RGB, convert to grayscale
            l2 = rgb2gray(l1);
        elseif length(size(l1)) == 2
            % the image is already grayscale
            l2 = l1;
        else
            fprintf('Unknown image type: %s\n', filepath);
            continue;
        end
        
        % 3. resize to make the longer side 1000 pixels
        [numrows, numcols] = size(l2);
        if numrows > numcols
            l3 = imresize(l2, [1000, NaN]);
        else
            l3 = imresize(l2, [NaN, 1000]);
        end
        
        % 4. convert to double
        l3 = im2double(l3);
        
        % 5. generate noise
        noise = randn(size(l3));
        
        % 6. add noise
        l4 = l3 + noise;
        
        % 7. make the gray scale [0, 1]
        min_gray = min(min(l4));
        max_gray = max(max(l4));
        l4 = (l4 - min_gray) ./ (max_gray - min_gray);
        
        % 8. display images
        figure; hold on;
        suptitle(basename);
        subplot(1, 3, 1); imshow(l3); title('original image');
        subplot(1, 3, 2); imshow(noise); title('noise');
        subplot(1, 3, 3); imshow(l4); title('image with noise');
        hold off;
        
        % 9. save images
        try
            save_path = fullfile(path, strcat(basename, '.bmp'));
            imwrite(l4, save_path);
        catch
            fprintf('Unable to write file: %s', save_path);
        end
    end
end