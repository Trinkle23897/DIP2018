TEST_TIMES = 100;

fprintf('n\tloop\tvectorized\n');
for n = [10, 100, 1000, 10000]
    loop_time = zeros(TEST_TIMES, 1);
    vec_time = zeros(TEST_TIMES, 1);
    for i = 1:TEST_TIMES
        tic; hilbert_mat_loop(n); loop_time(i) = toc;
        tic; hilbert_mat_vec(n); vec_time(i) = toc;
    end
    fprintf('%d\t%f\t%f\n', n, mean(loop_time), mean(vec_time));
end

function H = hilbert_mat_vec(n)
    I = repmat(1:n, n, 1);
    J = I';
    H = 1 ./ (I + J - 1);
end

function H = hilbert_mat_loop(n)
    H = zeros(n, n);
    for i = 1:n
        for j = 1:n
            H(i, j) = 1 / (i + j - 1);
        end
    end
end